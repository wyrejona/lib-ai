<?php
/**
 * Chat widget template
 */
?>
<div id="ai-chatbot-widget" class="ai-chatbot-widget" style="display: none;">
    <div class="ai-chatbot-header">
        <div class="ai-chatbot-avatar">
            <img src="<?php echo esc_url(get_option('ai_chatbot_avatar_url', AI_CHATBOT_PLUGIN_URL . 'assets/images/default-avatar.png')); ?>" alt="AI Assistant">
        </div>
        <div class="ai-chatbot-info">
            <h3 class="ai-chatbot-title"><?php echo esc_html(get_option('ai_chatbot_chat_title', 'AI Assistant')); ?></h3>
            <span class="ai-chatbot-status">Online</span>
        </div>
        <button class="ai-chatbot-minimize">−</button>
        <button class="ai-chatbot-close">×</button>
    </div>
    
    <div class="ai-chatbot-body">
        <div class="ai-chatbot-messages">
            <div class="ai-chatbot-welcome-message">
                <?php echo esc_html(get_option('ai_chatbot_welcome_message', 'Hi buddy, I am your AI assistant, how may I help you today?')); ?>
            </div>
        </div>
    </div>
    
    <div class="ai-chatbot-footer">
        <div class="ai-chatbot-input-container">
            <input type="text" class="ai-chatbot-input" placeholder="Type your message here..." maxlength="500">
            <button class="ai-chatbot-send">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path d="M22 2L11 13" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
        </div>
    </div>
</div>

<button id="ai-chatbot-toggle" class="ai-chatbot-toggle">
    <div class="ai-chatbot-toggle-avatar">
        <img src="<?php echo esc_url(get_option('ai_chatbot_avatar_url', AI_CHATBOT_PLUGIN_URL . 'assets/images/default-avatar.png')); ?>" alt="AI Assistant">
    </div>
</button>
