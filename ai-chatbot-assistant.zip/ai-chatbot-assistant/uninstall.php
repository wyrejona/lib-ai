<?php
/**
 * Uninstall script for AI Chatbot Assistant
 * 
 * This file is called when the plugin is deleted from WordPress.
 * It removes all plugin options from the database.
 */

// If uninstall is not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete all plugin options
$options = array(
    'ai_chatbot_api_url',
    'ai_chatbot_welcome_message',
    'ai_chatbot_position',
    'ai_chatbot_avatar_url',
    'ai_chatbot_enable_chat',
    'ai_chatbot_chat_title',
    'ai_chatbot_primary_color',
    'ai_chatbot_text_color',
    'ai_chatbot_font_size',
    'ai_chatbot_auto_open',
    'ai_chatbot_show_on_mobile',
    'ai_chatbot_delay_seconds'
);

foreach ($options as $option) {
    delete_option($option);
}

// If using multisite, delete from all sites
if (is_multisite()) {
    $sites = get_sites();
    foreach ($sites as $site) {
        switch_to_blog($site->blog_id);
        foreach ($options as $option) {
            delete_option($option);
        }
        restore_current_blog();
    }
}
