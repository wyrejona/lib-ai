=== AI Chatbot Assistant ===
Contributors: yourname
Tags: chatbot, ai, assistant, chat, widget
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate your custom AI chatbot into WordPress with customizable settings.

== Description ==

AI Chatbot Assistant allows you to integrate your custom AI chatbot API into your WordPress website with a beautiful, customizable chat widget.

= Features =

* Connect to your AI API endpoint
* Customizable chatbot avatar
* Multiple position options (bottom-right, bottom-left, floating)
* Customizable welcome message
* Color scheme customization
* Mobile-responsive design
* Auto-open on page load
* Configurable delay for auto-open
* Option to hide on mobile devices
* Live preview in admin settings

= Installation =

1. Upload the `ai-chatbot-assistant` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to AI Chatbot > Settings to configure your chatbot
4. Set your API endpoint URL and customize the appearance

= Configuration =

1. **API Endpoint URL**: Enter your AI chat API URL (e.g., http://41.89.240.119:8000/chat)
2. **Chatbot Avatar**: Upload or select an image for your chatbot
3. **Position**: Choose where the chat widget appears (bottom-right, bottom-left, or floating)
4. **Welcome Message**: Set the initial greeting message
5. **Colors**: Customize primary and text colors
6. **Behavior**: Configure auto-open, delay, and mobile visibility

= API Integration =

The plugin sends POST requests to your API endpoint with the following JSON format:
{
    "message": "user message here"
}

Your API should respond with JSON in this format:
{
    "response": "chatbot reply here"
}

== Frequently Asked Questions ==

= What API format does the plugin use? =
The plugin sends JSON POST requests to your API endpoint and expects JSON responses.

= Can I customize the chatbot appearance? =
Yes! You can change colors, position, avatar, and welcome message from the settings page.

= Does it work on mobile? =
Yes, the chat widget is fully responsive and works on all devices.

= Can I disable the chatbot on certain pages? =
Currently, the plugin shows the chatbot on all pages. Future updates may include page-specific controls.

== Changelog ==

= 1.0.0 =
* Initial release
* Basic chat functionality
* Admin settings interface
* Customizable appearance
* API integration

== Upgrade Notice ==

= 1.0.0 =
Initial release of AI Chatbot Assistant.
