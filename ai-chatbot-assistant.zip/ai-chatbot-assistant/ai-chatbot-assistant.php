<?php
/**
 * Plugin Name: AI Chatbot Assistant
 * Plugin URI: https://yourwebsite.com
 * Description: Integrate your custom AI chatbot into WordPress with customizable settings
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: ai-chatbot-assistant
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AI_CHATBOT_VERSION', '1.0.0');
define('AI_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AI_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AI_CHATBOT_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'AI_Chatbot_';
    $base_dir = AI_CHATBOT_PLUGIN_DIR . 'includes/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . 'class-' . str_replace('_', '-', strtolower($relative_class)) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Initialize the plugin
function ai_chatbot_init() {
    $plugin = new AI_Chatbot_Init();
    $plugin->run();
}
add_action('plugins_loaded', 'ai_chatbot_init');

// Activation hook
register_activation_hook(__FILE__, function() {
    require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-ai-chatbot-init.php';
    AI_Chatbot_Init::activate();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-ai-chatbot-init.php';
    AI_Chatbot_Init::deactivate();
});
