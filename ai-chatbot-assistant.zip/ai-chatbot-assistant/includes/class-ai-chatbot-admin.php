<?php
class AI_Chatbot_Admin {
    
    public function add_admin_menu() {
        add_menu_page(
            'AI Chatbot Settings',
            'AI Chatbot',
            'manage_options',
            'ai-chatbot-settings',
            array($this, 'display_settings_page'),
            'dashicons-format-chat',
            30
        );
        
        add_submenu_page(
            'ai-chatbot-settings',
            'Settings',
            'Settings',
            'manage_options',
            'ai-chatbot-settings',
            array($this, 'display_settings_page')
        );
    }
    
    public function display_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form method="post" action="options.php" enctype="multipart/form-data">
                <?php
                settings_fields('ai_chatbot_settings');
                do_settings_sections('ai-chatbot-settings');
                submit_button('Save Settings');
                ?>
            </form>
            
            <div class="chatbot-preview">
                <h3>Live Preview</h3>
                <div id="chatbot-preview-container">
                    <!-- Preview will be loaded via JavaScript -->
                </div>
            </div>
        </div>
        <?php
    }
    
    public function register_settings() {
        // General Settings
        add_settings_section(
            'ai_chatbot_general',
            'General Settings',
            null,
            'ai-chatbot-settings'
        );
        
        add_settings_field(
            'ai_chatbot_api_url',
            'API Endpoint URL',
            array($this, 'api_url_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_general'
        );
        
        add_settings_field(
            'ai_chatbot_enable_chat',
            'Enable Chatbot',
            array($this, 'enable_chat_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_general'
        );
        
        // Appearance Settings
        add_settings_section(
            'ai_chatbot_appearance',
            'Appearance Settings',
            null,
            'ai-chatbot-settings'
        );
        
        add_settings_field(
            'ai_chatbot_position',
            'Chat Widget Position',
            array($this, 'position_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_appearance'
        );
        
        add_settings_field(
            'ai_chatbot_avatar',
            'Chatbot Avatar',
            array($this, 'avatar_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_appearance'
        );
        
        add_settings_field(
            'ai_chatbot_chat_title',
            'Chat Title',
            array($this, 'chat_title_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_appearance'
        );
        
        add_settings_field(
            'ai_chatbot_primary_color',
            'Primary Color',
            array($this, 'color_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_appearance',
            array('field' => 'primary_color')
        );
        
        add_settings_field(
            'ai_chatbot_text_color',
            'Text Color',
            array($this, 'color_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_appearance',
            array('field' => 'text_color')
        );
        
        // Behavior Settings
        add_settings_section(
            'ai_chatbot_behavior',
            'Behavior Settings',
            null,
            'ai-chatbot-settings'
        );
        
        add_settings_field(
            'ai_chatbot_welcome_message',
            'Welcome Message',
            array($this, 'welcome_message_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_behavior'
        );
        
        add_settings_field(
            'ai_chatbot_auto_open',
            'Auto Open on Page Load',
            array($this, 'auto_open_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_behavior'
        );
        
        add_settings_field(
            'ai_chatbot_delay_seconds',
            'Auto Open Delay (seconds)',
            array($this, 'delay_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_behavior'
        );
        
        add_settings_field(
            'ai_chatbot_show_on_mobile',
            'Show on Mobile Devices',
            array($this, 'mobile_callback'),
            'ai-chatbot-settings',
            'ai_chatbot_behavior'
        );
        
        // Register all settings
        $settings = array(
            'api_url',
            'enable_chat',
            'position',
            'avatar_url',
            'chat_title',
            'primary_color',
            'text_color',
            'welcome_message',
            'auto_open',
            'delay_seconds',
            'show_on_mobile',
            'font_size'
        );
        
        foreach ($settings as $setting) {
            register_setting('ai_chatbot_settings', 'ai_chatbot_' . $setting);
        }
    }
    
    public function api_url_callback() {
        $value = get_option('ai_chatbot_api_url', 'http://41.89.240.119:8000/chat');
        echo '<input type="url" class="regular-text" name="ai_chatbot_api_url" value="' . esc_attr($value) . '" placeholder="http://your-api-endpoint.com/chat">';
        echo '<p class="description">Enter the full URL to your AI chat API endpoint</p>';
    }
    
    public function enable_chat_callback() {
        $value = get_option('ai_chatbot_enable_chat', '1');
        echo '<label><input type="checkbox" name="ai_chatbot_enable_chat" value="1" ' . checked('1', $value, false) . '> Enable chatbot on website</label>';
    }
    
    public function position_callback() {
        $value = get_option('ai_chatbot_position', 'bottom-right');
        $positions = array(
            'bottom-right' => 'Bottom Right',
            'bottom-left' => 'Bottom Left',
            'floating' => 'Floating (center right)'
        );
        
        echo '<select name="ai_chatbot_position">';
        foreach ($positions as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }
    
    public function avatar_callback() {
        $avatar_url = get_option('ai_chatbot_avatar_url', AI_CHATBOT_PLUGIN_URL . 'assets/images/default-avatar.png');
        echo '<div class="avatar-upload">';
        echo '<img id="avatar-preview" src="' . esc_url($avatar_url) . '" style="width: 100px; height: 100px; border-radius: 50%; margin-bottom: 10px;">';
        echo '<input type="hidden" id="ai_chatbot_avatar_url" name="ai_chatbot_avatar_url" value="' . esc_url($avatar_url) . '">';
        echo '<input type="button" class="button" value="Upload Avatar" onclick="uploadAvatar()">';
        echo '<p class="description">Upload or select an image for the chatbot avatar</p>';
        echo '</div>';
    }
    
    public function chat_title_callback() {
        $value = get_option('ai_chatbot_chat_title', 'AI Assistant');
        echo '<input type="text" class="regular-text" name="ai_chatbot_chat_title" value="' . esc_attr($value) . '">';
    }
    
    public function color_callback($args) {
        $field = $args['field'];
        $value = get_option('ai_chatbot_' . $field, $field === 'primary_color' ? '#3a86ff' : '#ffffff');
        echo '<input type="color" name="ai_chatbot_' . $field . '" value="' . esc_attr($value) . '">';
    }
    
    public function welcome_message_callback() {
        $value = get_option('ai_chatbot_welcome_message', 'Hi buddy, I am your AI assistant, how may I help you today?');
        echo '<textarea name="ai_chatbot_welcome_message" rows="3" cols="50" class="large-text">' . esc_textarea($value) . '</textarea>';
    }
    
    public function auto_open_callback() {
        $value = get_option('ai_chatbot_auto_open', '0');
        echo '<label><input type="checkbox" name="ai_chatbot_auto_open" value="1" ' . checked('1', $value, false) . '> Automatically open chat on page load</label>';
    }
    
    public function delay_callback() {
        $value = get_option('ai_chatbot_delay_seconds', '3');
        echo '<input type="number" min="0" max="60" name="ai_chatbot_delay_seconds" value="' . esc_attr($value) . '"> seconds';
    }
    
    public function mobile_callback() {
        $value = get_option('ai_chatbot_show_on_mobile', '1');
        echo '<label><input type="checkbox" name="ai_chatbot_show_on_mobile" value="1" ' . checked('1', $value, false) . '> Show chatbot on mobile devices</label>';
    }
    
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_ai-chatbot-settings') {
            return;
        }
        
        wp_enqueue_media();
        wp_enqueue_style('ai-chatbot-admin', AI_CHATBOT_PLUGIN_URL . 'assets/css/admin.css', array(), AI_CHATBOT_VERSION);
        wp_enqueue_script('ai-chatbot-admin', AI_CHATBOT_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), AI_CHATBOT_VERSION, true);
        
        wp_localize_script('ai-chatbot-admin', 'ai_chatbot_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_chatbot_admin_nonce'),
            'plugin_url' => AI_CHATBOT_PLUGIN_URL
        ));
    }
}
