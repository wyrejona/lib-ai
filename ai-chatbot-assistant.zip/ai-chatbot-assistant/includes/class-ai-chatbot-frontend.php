<?php
class AI_Chatbot_Frontend {
    
    public function enqueue_public_scripts() {
        if (!get_option('ai_chatbot_enable_chat', '1')) {
            return;
        }
        
        wp_enqueue_style('ai-chatbot-frontend', AI_CHATBOT_PLUGIN_URL . 'assets/css/frontend.css', array(), AI_CHATBOT_VERSION);
        wp_enqueue_script('ai-chatbot-frontend', AI_CHATBOT_PLUGIN_URL . 'assets/js/frontend.js', array('jquery'), AI_CHATBOT_VERSION, true);
        
        $settings = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'api_url' => get_option('ai_chatbot_api_url', 'http://41.89.240.119:8000/chat'),
            'welcome_message' => get_option('ai_chatbot_welcome_message', 'Hi buddy, I am your AI assistant, how may I help you today?'),
            'position' => get_option('ai_chatbot_position', 'bottom-right'),
            'avatar_url' => get_option('ai_chatbot_avatar_url', AI_CHATBOT_PLUGIN_URL . 'assets/images/default-avatar.png'),
            'chat_title' => get_option('ai_chatbot_chat_title', 'AI Assistant'),
            'primary_color' => get_option('ai_chatbot_primary_color', '#3a86ff'),
            'text_color' => get_option('ai_chatbot_text_color', '#ffffff'),
            'auto_open' => get_option('ai_chatbot_auto_open', '0') === '1',
            'delay_seconds' => intval(get_option('ai_chatbot_delay_seconds', '3')),
            'show_on_mobile' => get_option('ai_chatbot_show_on_mobile', '1') === '1',
            'nonce' => wp_create_nonce('ai_chatbot_nonce')
        );
        
        wp_localize_script('ai-chatbot-frontend', 'ai_chatbot_settings', $settings);
    }
    
    public function display_chat_widget() {
        if (!get_option('ai_chatbot_enable_chat', '1')) {
            return;
        }
        
        $show_on_mobile = get_option('ai_chatbot_show_on_mobile', '1') === '1';
        $is_mobile = wp_is_mobile();
        
        if (!$show_on_mobile && $is_mobile) {
            return;
        }
        
        include AI_CHATBOT_PLUGIN_DIR . 'templates/chat-widget.php';
    }
}
