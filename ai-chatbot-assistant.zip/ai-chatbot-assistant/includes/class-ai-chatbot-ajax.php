<?php
class AI_Chatbot_Ajax {
    
    public function send_message() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'ai_chatbot_nonce')) {
            wp_die('Security check failed');
        }
        
        $message = sanitize_text_field($_POST['message']);
        $api_url = get_option('ai_chatbot_api_url', 'http://41.89.240.119:8000/chat');
        
        // Prepare the request to your AI API
        $response = wp_remote_post($api_url, array(
            'timeout' => 30,
            'body' => json_encode(array('message' => $message)),
            'headers' => array('Content-Type' => 'application/json')
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Sorry, I am having trouble connecting right now.'));
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['response'])) {
            wp_send_json_success(array('message' => $data['response']));
        } else {
            wp_send_json_error(array('message' => 'Sorry, I could not process your request.'));
        }
    }
}
