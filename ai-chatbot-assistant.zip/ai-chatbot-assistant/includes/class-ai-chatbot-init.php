<?php
class AI_Chatbot_Init {
    
    public function run() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }
    
    private function load_dependencies() {
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-ai-chatbot-admin.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-ai-chatbot-frontend.php';
        require_once AI_CHATBOT_PLUGIN_DIR . 'includes/class-ai-chatbot-ajax.php';
    }
    
    private function set_locale() {
        load_plugin_textdomain(
            'ai-chatbot-assistant',
            false,
            dirname(AI_CHATBOT_PLUGIN_BASENAME) . '/languages/'
        );
    }
    
    private function define_admin_hooks() {
        $admin = new AI_Chatbot_Admin();
        add_action('admin_menu', array($admin, 'add_admin_menu'));
        add_action('admin_init', array($admin, 'register_settings'));
        add_action('admin_enqueue_scripts', array($admin, 'enqueue_admin_scripts'));
    }
    
    private function define_public_hooks() {
        $frontend = new AI_Chatbot_Frontend();
        add_action('wp_enqueue_scripts', array($frontend, 'enqueue_public_scripts'));
        add_action('wp_footer', array($frontend, 'display_chat_widget'));
        
        $ajax = new AI_Chatbot_Ajax();
        add_action('wp_ajax_send_chat_message', array($ajax, 'send_message'));
        add_action('wp_ajax_nopriv_send_chat_message', array($ajax, 'send_message'));
    }
    
    public static function activate() {
        // Default settings
        $defaults = array(
            'api_url' => 'http://41.89.240.119:8000/chat',
            'welcome_message' => 'Hi buddy, I am your AI assistant, how may I help you today?',
            'position' => 'bottom-right',
            'avatar_url' => AI_CHATBOT_PLUGIN_URL . 'assets/images/default-avatar.png',
            'enable_chat' => '1',
            'chat_title' => 'AI Assistant',
            'primary_color' => '#3a86ff',
            'text_color' => '#ffffff',
            'font_size' => '14',
            'auto_open' => '0',
            'show_on_mobile' => '1',
            'delay_seconds' => '3'
        );
        
        foreach ($defaults as $key => $value) {
            if (get_option('ai_chatbot_' . $key) === false) {
                add_option('ai_chatbot_' . $key, $value);
            }
        }
    }
    
    public static function deactivate() {
        // Clean up if needed
    }
}
