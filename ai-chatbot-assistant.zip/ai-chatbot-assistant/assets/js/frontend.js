(function($) {
    'use strict';
    
    const settings = window.ai_chatbot_settings;
    
    class Chatbot {
        constructor() {
            this.widget = $('#ai-chatbot-widget');
            this.toggle = $('#ai-chatbot-toggle');
            this.messagesContainer = $('.ai-chatbot-messages');
            this.input = $('.ai-chatbot-input');
            this.sendButton = $('.ai-chatbot-send');
            this.minimizeButton = $('.ai-chatbot-minimize');
            this.closeButton = $('.ai-chatbot-close');
            this.isOpen = false;
            this.isMobile = window.innerWidth <= 768;
            
            this.init();
        }
        
        init() {
            this.applyPosition();
            this.applyColors();
            this.bindEvents();
            
            if (settings.auto_open && !this.isMobile) {
                setTimeout(() => {
                    this.open();
                }, settings.delay_seconds * 1000);
            }
        }
        
        applyPosition() {
            this.widget.addClass(settings.position);
            this.toggle.addClass(settings.position);
            
            if (settings.position === 'floating') {
                this.widget.css({
                    'bottom': '50%',
                    'right': '30px',
                    'transform': 'translateY(50%)'
                });
                this.toggle.css({
                    'bottom': '50%',
                    'right': '20px',
                    'transform': 'translateY(50%)'
                });
            }
        }
        
        applyColors() {
            document.documentElement.style.setProperty('--ai-primary-color', settings.primary_color);
            document.documentElement.style.setProperty('--ai-text-color', settings.text_color);
            
            if (settings.position === 'floating') {
                this.toggle.css('background-color', settings.primary_color);
            }
        }
        
        bindEvents() {
            this.toggle.on('click', () => this.toggleChat());
            this.minimizeButton.on('click', () => this.close());
            this.closeButton.on('click', () => this.close());
            this.sendButton.on('click', () => this.sendMessage());
            this.input.on('keypress', (e) => {
                if (e.which === 13) {
                    this.sendMessage();
                }
            });
            
            // Close on click outside
            $(document).on('click', (e) => {
                if (this.isOpen && 
                    !$(e.target).closest('#ai-chatbot-widget').length && 
                    !$(e.target).closest('#ai-chatbot-toggle').length) {
                    this.close();
                }
            });
        }
        
        toggleChat() {
            if (this.isOpen) {
                this.close();
            } else {
                this.open();
            }
        }
        
        open() {
            this.widget.fadeIn(200);
            this.toggle.fadeOut(200);
            this.isOpen = true;
            this.input.focus();
        }
        
        close() {
            this.widget.fadeOut(200);
            this.toggle.fadeIn(200);
            this.isOpen = false;
        }
        
        sendMessage() {
            const message = this.input.val().trim();
            if (!message) return;
            
            this.addMessage(message, 'user');
            this.input.val('');
            
            this.showTypingIndicator();
            
            $.ajax({
                url: settings.ajax_url,
                type: 'POST',
                data: {
                    action: 'send_chat_message',
                    message: message,
                    nonce: settings.nonce
                },
                success: (response) => {
                    this.removeTypingIndicator();
                    if (response.success) {
                        this.addMessage(response.data.message, 'bot');
                    } else {
                        this.addMessage('Sorry, there was an error processing your request.', 'bot');
                    }
                },
                error: () => {
                    this.removeTypingIndicator();
                    this.addMessage('Sorry, I am having trouble connecting right now. Please try again later.', 'bot');
                }
            });
        }
        
        addMessage(text, sender) {
            const messageClass = sender === 'user' ? 'ai-chatbot-user-message' : 'ai-chatbot-bot-message';
            const messageHtml = `
                <div class="ai-chatbot-message ${messageClass}">
                    <div class="ai-chatbot-message-content">${this.escapeHtml(text)}</div>
                </div>
            `;
            
            this.messagesContainer.append(messageHtml);
            this.scrollToBottom();
        }
        
        showTypingIndicator() {
            const typingHtml = `
                <div class="ai-chatbot-typing-indicator">
                    <div class="ai-chatbot-typing-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            `;
            
            this.messagesContainer.append(typingHtml);
            this.scrollToBottom();
        }
        
        removeTypingIndicator() {
            $('.ai-chatbot-typing-indicator').remove();
        }
        
        scrollToBottom() {
            this.messagesContainer.scrollTop(this.messagesContainer[0].scrollHeight);
        }
        
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }
    
    // Initialize when DOM is ready
    $(document).ready(() => {
        new Chatbot();
    });
    
})(jQuery);
