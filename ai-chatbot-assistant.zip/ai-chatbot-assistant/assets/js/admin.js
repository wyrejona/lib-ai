(function($) {
    'use strict';
    
    function uploadAvatar() {
        const frame = wp.media({
            title: 'Select Chatbot Avatar',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });
        
        frame.on('select', function() {
            const attachment = frame.state().get('selection').first().toJSON();
            $('#avatar-preview').attr('src', attachment.url);
            $('#ai_chatbot_avatar_url').val(attachment.url);
        });
        
        frame.open();
    }
    
    function updatePreview() {
        // Update live preview based on settings
        const position = $('select[name="ai_chatbot_position"]').val();
        const primaryColor = $('input[name="ai_chatbot_primary_color"]').val();
        const textColor = $('input[name="ai_chatbot_text_color"]').val();
        const avatarUrl = $('#ai_chatbot_avatar_url').val();
        
        $('#chatbot-preview-container').html(`
            <div class="preview-widget" style="
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                max-width: 300px;
                margin: 0 auto;
            ">
                <div class="preview-header" style="
                    background: ${primaryColor};
                    color: ${textColor};
                    padding: 15px;
                    border-radius: 8px 8px 0 0;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                ">
                    <img src="${avatarUrl}" alt="Preview" style="
                        width: 40px;
                        height: 40px;
                        border-radius: 50%;
                        border: 2px solid rgba(255,255,255,0.3);
                    ">
                    <div>
                        <div style="font-weight: bold;">${$('input[name="ai_chatbot_chat_title"]').val()}</div>
                        <div style="font-size: 12px; opacity: 0.9;">Online</div>
                    </div>
                </div>
                <div class="preview-body" style="
                    padding: 15px;
                    background: #f8f9fa;
                    border-radius: 0 0 8px 8px;
                ">
                    <div style="
                        background: white;
                        padding: 10px;
                        border-radius: 8px;
                        font-size: 14px;
                        margin-bottom: 10px;
                    ">${$('textarea[name="ai_chatbot_welcome_message"]').val()}</div>
                    <div style="
                        display: flex;
                        gap: 10px;
                    ">
                        <input type="text" placeholder="Type message..." style="
                            flex: 1;
                            padding: 8px 12px;
                            border: 1px solid #ddd;
                            border-radius: 20px;
                            font-size: 14px;
                        " disabled>
                        <button style="
                            width: 36px;
                            height: 36px;
                            border-radius: 50%;
                            background: ${primaryColor};
                            border: none;
                            color: white;
                            cursor: pointer;
                        ">→</button>
                    </div>
                </div>
            </div>
            <p style="text-align: center; margin-top: 10px; color: #666;">
                Position: ${position} | Colors will update in real-time
            </p>
        `);
    }
    
    $(document).ready(function() {
        window.uploadAvatar = uploadAvatar;
        
        // Update preview when settings change
        $('input, select, textarea').on('change input', function() {
            updatePreview();
        });
        
        // Initial preview
        updatePreview();
    });
    
})(jQuery);
